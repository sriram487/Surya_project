import onnxruntime as ort
import numpy as np

onnx_model = ort.InferenceSession('onnx_weights/score_net.onnx')

A = np.random.rand(252, 6, 160, 160).astype(np.float32)
B = np.random.rand(252, 6, 160, 160).astype(np.float32)

outputs = onnx_model.run(None, {
   onnx_model.get_inputs()[0].name: A,
   onnx_model.get_inputs()[1].name: B,
})

output_1 = outputs[0]
# output_2 = outputs[1]

print(output_1.shape)
# print(output_2.dtype)

print(output_1)
# print(output_2)