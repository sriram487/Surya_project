import onnx

# Load the ONNX model
model_path = "onnx_weights/score_net.onnx"
onnx_model = onnx.load(model_path)

# Print the model's graph
# print(onnx_model)

# Check the model for validity
onnx.checker.check_model(onnx_model)
print("Model is valid!")

# Print inputs and outputs
for input in onnx_model.graph.input:
    print(f"Input: {input.name}, Shape: {input.type.tensor_type.shape}")

for output in onnx_model.graph.output:
    print(f"Output: {output.name}, Shape: {output.type.tensor_type.shape}")

# for tensor in onnx_model.graph.initializer:
#     print(f"Name: {tensor.name}, Data Type: {onnx.TensorProto.DataType.Name(tensor.data_type)}")