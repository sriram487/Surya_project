''' import Flask Utils '''
import sys
import base64
import time
import argparse
from flask import Flask, render_template, Response, jsonify
import cv2
import random

# Model imports
from estimater import *
from datareader import *

sys.path.append('/home/ba1071/Desktop/yolov5')
from demo import run

app = Flask(__name__)
display_frames = False
model = None
pitch = 0
roll = 0
yaw = 0
depth_value = 0
itr = 0

class PoseEstimation:

   def __init__(self):
      self.data_dir = r'/home/ba1071/Desktop/FoundationPose_TRT/demo_data/Bag/rgb'
      self.K = np.array([[391.802, 0., 325.322], [0., 391.802, 240.897],[0., 0., 1.]])
      self.mesh = trimesh.load('/home/ba1071/Desktop/FoundationPose_TRT/demo_data/Bag/mesh/bag_ply.ply')
      self.to_origin, self.extents = trimesh.bounds.oriented_bounds(self.mesh)
      self.bbox = np.stack([-self.extents/2, self.extents/2], axis=0).reshape(2,3)

      # initializing the model params
      self.scorer = ScorePredictor()
      self.glctx = dr.RasterizeCudaContext()
      self.refiner = PoseRefinePredictor()

      print('Done so Farrr')

      self.est = FoundationPose(model_pts=self.mesh.vertices, model_normals=self.mesh.vertex_normals, mesh=self.mesh, 
                                 scorer=self.scorer, refiner=self.refiner, debug_dir='./debug', debug=1, glctx=self.glctx)
      
   def encode_image(self, rgb, mask, pose):
     
      return [
         # cv2.imencode('.jpg', rgb)[1].tostring(),
         # cv2.imencode('.jpg', mask)[1].tostring(),
         # cv2.imencode('.jpg', pose)[1].tostring()

         base64.b64encode(cv2.imencode('.jpg', rgb)[1]).decode(),
         base64.b64encode(cv2.imencode('.jpg', mask)[1]).decode(),
         base64.b64encode(cv2.imencode('.jpg', pose)[1]).decode()
      ]

   def get_frames(self):
      
      '''
         Function that iterate through the data dir
         and return the annotated
      '''

      global display_frames
      global pitch
      global roll
      global yaw
      global depth_values

      global itr

      data_dict = {}
      data_list = []

      if display_frames == True:
         
         #for i in os.listdir(self.data_dir):
         
         i = str(random.randint(0, 101)) + '.png'

         img_dir = self.data_dir + '/' + i
         depth_dir = self.data_dir.replace('rgb', 'depth') + '/' + i

         color = cv2.imread(img_dir)   
         color = cv2.cvtColor(color, cv2.COLOR_BGR2RGB)

         depth = cv2.imread(depth_dir, -1)/1e3
         depth = cv2.resize(depth, (640,480), interpolation=cv2.INTER_NEAREST)
         depth_cpy = depth
         depth[(depth<0.1) | (depth>=np.inf)] = 0

         mask, xyxy = run(color)

         if itr == 0:
            pose = self.est.register(K=self.K, rgb=color, depth=depth, ob_mask=mask, iteration=5)
            # itr += 1
         else:
            pose = self.est.track_one(rgb=color, depth=depth, K=self.K, iteration=2)

         R = pose[:3, :3]
         T = pose[:3, 3]

         pitch = -np.arcsin(R[2, 0])
         roll = np.arctan2(R[2, 1], R[2, 2])
         yaw = np.arctan2(R[1, 0], R[0, 0])
         masked_depth = cv2.bitwise_and(depth_cpy, depth_cpy, mask=mask)

         depth_value = np.median(masked_depth[mask > 0])

         center_pose = pose@np.linalg.inv(self.to_origin)
         vis = draw_posed_3d_box(self.K, img=color, ob_in_cam=center_pose, bbox=self.bbox)
         vis = draw_xyz_axis(color, ob_in_cam=center_pose, scale=0.1, K=self.K, thickness=3, transparency=0, is_input_rgb=True)

         images = self.encode_image(color, mask, vis)

         return jsonify(images)

model = PoseEstimation()

@app.route('/')
def index():
  
  '''
    Default Index Route that is getting called
    while loading the webpage
  '''
  return render_template('index.html')


@app.route('/video_feed')
def video_feed():    
    
    global model

    return model.get_frames()

@app.route('/update_data')
def update_data():

     global pitch
     global roll
     global yaw
     global depth_value

     return jsonify([int(pitch), int(roll),
              int(yaw), int(depth_value)])


@app.route('/start_display')
def start_display():
    global display_frames
    if display_frames == False:
      display_frames = True
    else:
       display_frames = False
    
    return jsonify(display_frames = display_frames)


if __name__ == '__main__':
    app.run(debug=True)
    


