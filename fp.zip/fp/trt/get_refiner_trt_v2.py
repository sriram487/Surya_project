import tensorrt as trt
from logzero import logger
import yaml
import os
import argparse

TRT_LOGGER = trt.Logger(trt.Logger.VERBOSE)
EXPLICIT_BATCH = 1 << (int)(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)
EXPLICIT_BATCH |= 1 << int(trt.NetworkDefinitionCreationFlag.EXPLICIT_BATCH)

def build_engine(model_path, quantize="fp16"):

    with trt.Builder(TRT_LOGGER) as builder, \
        builder.create_network(EXPLICIT_BATCH) as network, \
        builder.create_builder_config() as config, \
        trt.OnnxParser(network, TRT_LOGGER) as parser:
        
        # config.max_workspace_size = 1 << 50
        config.set_memory_pool_limit(trt.MemoryPoolType.WORKSPACE, 1 << 50)
        # config.max_batch_size = 1

    if quantize == "fp16":
        config.flags |= 1 << int(trt.BuilderFlag.FP16)

    config.profiling_verbosity = trt.ProfilingVerbosity.DETAILED
    config.default_device_type = trt.DeviceType.GPU

    with open(model_path, "rb") as f:
        if not parser.parse(f.read()):
            print('ERROR: Failed to parse the ONNX file.')
            for error in range(parser.num_errors):
                logger.error(parser.get_error(error))

    logger.info("ONNX parse ended")
    profile = builder.create_optimization_profile()
    network.add_input("inputA", trt.float32, (-1, -1, -1, -1))
    network.add_input("inputB", trt.float32, (-1, -1, -1, -1))
    # profile.set_shape("input_A", config.model.input_min_size, config.model.input_opt_size, config.model.input_max_size)
    # profile.set_shape("input_B", config.model.input_min_size, config.model.input_opt_size, config.model.input_max_size)
    
    profile.set_shape('inputA', [1, 6, 160, 160], [252, 6, 160, 160], [252, 6, 160, 160])  # First input
    profile.set_shape('inputB', [1, 6, 160, 160], [252, 6, 160, 160], [252, 6, 160, 160])  # Second input

    config.add_optimization_profile(profile)

    logger.debug(f"config = {config}")

    logger.info("====================== building tensorrt engine... ======================")
    engine = builder.build_serialized_network(network, config)
    logger.info("engine was created successfully")

    with open("trt_weights/refiner.engine", 'wb') as f:
        try:
            f.write(bytearray(engine))
        except:
            logger.error("file not writen")

    return engine

if __name__ == '__main__':

    build_engine( model_path='/home/ba1071/Desktop/pose_trt/onnx_weights/refiner_net.onnx',
                 quantize="None")